import { useForm } from "react-hook-form";
import { useRegisterNewVehicleMutation } from "../services/api";
import { object, string } from "yup";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Link } from "react-router-dom";

type formValue = {
  vehicleName: string;
  vehicleType: string;
  vehicleNumber: string;
};

const RegisterVehicle = () => {
  const [err, setErr] = useState("");
  const [serr, setSerr] = useState("");

  const form = useForm<formValue>();
  const { register, handleSubmit } = form;
  const [registerVehicle] = useRegisterNewVehicleMutation();
  const navigate = useNavigate();

  const schema = object({
    vehicleName: string().required(),
    vehicleType: string().required(),
    vehicleNumber: string().required().min(9),
  });

  const onSubmit = async (data: formValue) => {
    const userData = schema.validate(data);

    userData
      .then(async (datas) => {
        console.log(datas);

        try {
          const payload = await registerVehicle(datas).unwrap();
          console.log("fulfilled", payload);
          navigate("/setstatus");
        } catch (error: any) {
          setErr(error.data.msg);
          setSerr(error.data.msg);
        }
      })
      .catch((error) => {
        const err = { error };
        setErr(err.error.message);
      });
  };

  return (
    <div className="w-screen h-screen flex justify-center items-center flex-col gap-5">
      <h1 className="text-orange-500 font-bold text-2xl">
        Register a new Vehicle
      </h1>
      <form
        className="w-[40%] h-[50%] border rounded-lg border-cyan-950 flex flex-col gap-7 px-10 py-8"
        onSubmit={handleSubmit(onSubmit)}
      >
        <div className=" w-full flex justify-between">
          <label
            htmlFor="vehicleName"
            className=" text-orange-500 font-semibold text-lg"
          >
            Vehicle Name:
          </label>
          <input
            className="w-[60%] border-black border rounded-md p-1"
            placeholder="Enter the vehicleName = car/bike"
            type="text"
            id="vehicleName"
            {...register("vehicleName")}
          />
        </div>

        <div className=" w-full flex justify-between">
          <label
            className=" text-orange-500 font-semibold text-lg"
            htmlFor="vehicleType"
          >
            Vehicle Type:
          </label>

          <label className=" text-orange-500 text-md" htmlFor="vehicleType">
            Two Wheeler:
          </label>
          <input
            className="w-[8%] border-blue-300 border-b-teal-400 "
            placeholder="Enter the vehicleType"
            type="radio"
            id="vehicleType"
            value="Two Wheeler"
            {...register("vehicleType")}
          />
          <label className=" text-orange-500 text-md" htmlFor="vehicleType">
            Four Wheeler:
          </label>
          <input
            className="w-[8%] border-blue-300 border-b-teal-400 "
            placeholder="Enter the vehicleType"
            type="radio"
            id="vehicleType"
            value="Four Wheeler"
            {...register("vehicleType")}
          />
        </div>

        <div className=" w-full flex justify-between">
          <label
            className=" text-orange-500 font-semibold text-lg"
            htmlFor="vehicleNumber"
          >
            Vehicle Number:
          </label>
          <input
            className="w-[60%] border-black border rounded-md p-1 "
            placeholder="Enter the vehicleNumber"
            type="text"
            id="vehicleNumber"
            {...register("vehicleNumber")}
          />
        </div>

        <button
          className="w-20 cursor-pointer h-12 rounded-md text-lg text-green-500 border-red-500 border font-bold"
          type="submit"
        >
          Submit
        </button>
      </form>
      {err && <p className="text-red-800 text-lg">{err}</p>}
      {serr && (
        <Link to="/">
          <p className="text-blue-800">Register again</p>
        </Link>
      )}
    </div>
  );
};

export default RegisterVehicle;
