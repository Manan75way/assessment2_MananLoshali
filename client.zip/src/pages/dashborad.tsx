import React from 'react'

const Dashboard = () => {
  return (
    <div>
      This is dashboard
    </div>
  )
}

export default Dashboard
