import mongoose from "mongoose";

const driverSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    vehicleName: {
      type: String,
      default: "",
    },
    vehicleType: {
      type: String,
      default: "",
    },
    vehicleNumber: {
      type: String,
      default: "",
    },
    isAvailable: {
      type: Boolean,
    },
    coordinates: {
      type: {
        type: String,
        default: "Point",
      },
      coordinates: {
        type: [Number],
        // index: "2dsphere", // Add an index for GeoJSON support
        default: [0, 0],
      },
    },
    availableRides: [
      {
        startPoint: {
          location: String,
          type: { type: String, default: "Start" },
          coordinates: [Number],
          default: [0, 0],
        },
        endingPoint: {
          location: String,
          type: { type: String, default: "Destination" },
          coordinates: [Number],
          default: [0, 0],
        },
        isAccepted: {
          type: String,
          default: "false",
        },
        status: {
          type: String,
          enum: ["start", "finish", "cancel"]
        },
        userId: {
          type: String
        }
      },
    ],
  },
  { timestamps: true }
);
// Create a 2dsphere index on the coordinates field
driverSchema.index({ coordinates: "2dsphere" });
export const Driver = mongoose.model("drivers", driverSchema);
