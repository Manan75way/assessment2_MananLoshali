import React, { useEffect, useState } from "react";
import { useFindRideHistoryMutation } from "../services/api";

const RideHistory = () => {
  const [rideHistory] = useFindRideHistoryMutation();
  const [ride, setRide] = useState([]);
  useEffect(() => {
    getRideHistory();
  }, []);

  const getRideHistory = async () => {
    try {
      const payload = await rideHistory().unwrap();
      console.log(payload.ride[0].availableRides);
      setRide(payload.ride[0].availableRides);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h1 className="text-center text-fuchsia-600 font-bold text-3xl font-mono">
        Rides History:
      </h1>
      {ride.length === 0 ? (
        <p>No rides found in history</p>
      ) : (
        <div>
          {ride.map((item: any) => (
            <div className="flex flex-col border border-red-400 mb-4 w-[50%] ml-4 p-4">
              <p> Starting Point- {item?.startPoint?.location}</p>
              <p>Ending Point- {item?.endingPoint?.location}</p>
              <p>Status- {item?.status}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RideHistory;
