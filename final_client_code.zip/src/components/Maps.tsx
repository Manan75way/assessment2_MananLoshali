import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker } from "react-leaflet";
import L from "leaflet";

import "leaflet/dist/leaflet.css";

interface Props {
  positions: [number, number] | undefined;
  end: [number, number] | undefined;
}

const Maps = (positions: Props) => {
  const [loc, setLoc] = useState<[number, number]>();
  const [dest, setDest] = useState<[number, number] | undefined>([
    30.7099713, 76.6899101,
  ]);

  useEffect(() => {
    setLoc(positions.positions);
    setDest(positions.end);
  }, [positions.positions]);

  const desti: [number, number] = [30.7099713, 76.6899101];

  return (
    <div>
      {loc && (
        <MapContainer
          center={loc}
          zoom={13}
          style={{ width: "100%", height: "500px" }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />

          {loc && (
            <Marker position={loc} icon={L.icon({ iconUrl: "/start.png" })} />
          )}

          {desti && (
            <Marker position={desti} icon={L.icon({ iconUrl: "/end.png" })} />
          )}
        </MapContainer>
      )}
    </div>
  );
};

export default Maps;
